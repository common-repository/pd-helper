=== PD helper ===
Contributors: carl-alberto
Donate link: https://carl.alber2.com/
Tags: wordpress, plugin, template, admin, dashboard, user
Requires at least: 3.9
Tested up to: 4.0
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This is a helper plugin that load the Podio PHP plugin that help you in doing customizations in Podio.

== Description ==

This is a helper plugin that load the Podio PHP plugin that help you in doing customizations in Podio packaged as a single WordPress plugin. Official library source: https://github.com/podio/podio-php

== Installation ==

Installing "PD helper" can be done either by searching for "PD helper" via the "Plugins > Add New" screen in your WordPress dashboard, or by using the following steps:

1. Download the plugin via WordPress.org
2. Upload the ZIP file through the 'Plugins > Add New > Upload' screen in your WordPress dashboard
3. Activate the plugin through the 'Plugins' menu in WordPress

== Screenshots ==

== Frequently Asked Questions ==

== Changelog ==

= 1.0 =
* 2017-01-01
* Initial release

== Upgrade Notice ==

= 1.0 =
* 2017-01-01
* Initial release
